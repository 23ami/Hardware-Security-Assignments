First run the extended_euclidean.v file and then run the testbench file  extended_euclidean_tb.v file.

I have set the value of a=2 and b=94849 and printed the output on the screen of the modular  multiplicative inverse
of a and b.
you can try on different values of a and b in the testbench.